/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe_3;

import static com.mycompany.poe_3.Login.SimpleUserRegistration.isValidPassword;
import static com.mycompany.poe_3.Login.SimpleUserRegistration.isValidPhoneNumber;
import static com.mycompany.poe_3.Login.SimpleUserRegistration.isValidUsername;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class POE_3 {

    public static void main(String[] args) {
         // Input for username
        try (Scanner scanner = new Scanner(System.in)) {
            // Input for username
            System.out.println("Enter username (max 5 characters, must contain an underscore): ");
            String username = scanner.nextLine();
            if (!isValidUsername(username)) {
                System.out.println("Invalid username!");
                return;
            }
            
            // Input for password
            System.out.println("Enter password (8 characters, special characters, number, capital letter): ");
            String password = scanner.nextLine();
            if (!isValidPassword(password)) {
                System.out.println("Invalid password!");
                return;
            }
            
            // Input for phone number
            System.out.println("Enter phone number ( start with +27): ");
            String phone = scanner.nextLine();
            if (!isValidPhoneNumber(phone)) {
                System.out.println("Ivalid phone number!");
                return;
            }
            
            System.out.println("Registration Successful!");
      
    

      
       }
     
       }}
   

