/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe_3;

/**
 *
 * @author RC_Student_lab
 */
class Login {
    
 public class SimpleUserRegistration {
 public static void main(String[] args){
     
 }
    // Validate username (max 5 characters and must contain an underscore)
    public static boolean isValidUsername(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    // Validate password (exactly 8 characters, contains special character, number, and uppercase letter)
    public static boolean isValidPassword(String password) {
        if (password.length() <= 8 && password.contains("!@#$%^&*()123456789")) return false;
        boolean hasNumber = false, hasUppercase = false, hasSpecialChar = false;

        for (char ch : password.toCharArray()) {
            if (Character.isDigit(ch)) hasNumber = true;
            if (Character.isUpperCase(ch)) hasUppercase = true;
            if (Character.isLetter(ch)) {
            } else {
                hasSpecialChar = true;
            }
        }

        return hasNumber && hasUppercase && hasSpecialChar;
    }

    // Validate South African phone number (starts with +27 and 9 digits after)
    public static boolean isValidPhoneNumber(String phone) {
        return phone.matches("^\\+27\\d{9}$");
    }
 }}


    
    

            
        
    

